//
//  GameScene.swift
//  BrexOut
//
//  Created by Pat on 04/05/2016.
//  Copyright (c) 2016 PatMac. All rights reserved.
//
import SpriteKit
    let GameOverLabelCategoryName = "gameOverLabel"
    class GameOverScene: SKScene {
    var gameWon : Bool = false {
    // 1.
    didSet {
    let gameOverLabel = childNodeWithName(GameOverLabelCategoryName) as! SKLabelNode
    gameOverLabel.text = gameWon ? "Game Won" : "Game Over"
    }
}
internal override func keyDown(theEvent: NSEvent) {
    if let view = view {
    // 2.
    let gameScene = GameScene(fileNamed: "GameScene") 
    view.presentScene(gameScene)
    }
  }
}