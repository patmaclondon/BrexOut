//
//  GameScene.swift
//  BrexOut
//
//  Created by Pat on 04/05/2016.
//  Copyright (c) 2016 PatMac. All rights reserved.
//
import SpriteKit
let BallCategoryName = "ball"
let PaddleCategoryName = "paddle"
let BlockCategoryName = "block"
let BlockNodeCategoryName = "blockNode"

let BallCategory   : UInt32 = 0x1 << 0 // 00000000000000000000000000000001
let BottomCategory : UInt32 = 0x1 << 1 // 00000000000000000000000000000010
let BlockCategory  : UInt32 = 0x1 << 2 // 00000000000000000000000000000100
var PaddleCategory : UInt32 = 0x1 << 3 // 00000000000000000000000000001000



class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        super.didMoveToView(view)
        // 1. Create a physics body that borders the screen
        let borderBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
        // 2. Set the friction of that physicsBody to 0
        borderBody.friction = 0
        // 3. Set physicsBody of scene to borderBody
        self.physicsBody = borderBody
        // 4. Bounce Ball Bounce!
        physicsWorld.gravity = CGVectorMake(0, 0)
        let ball = childNodeWithName(BallCategoryName) as! SKSpriteNode
        ball.physicsBody!.applyImpulse(CGVectorMake(40, -40))
        }
    
    override func keyDown(theEvent: NSEvent) {
        if let theArrow = theEvent.charactersIgnoringModifiers, keyChar = theArrow.unicodeScalars.first?.value{
        let paddle = childNodeWithName(PaddleCategoryName) as! SKSpriteNode
        switch Int (keyChar) {
        case NSLeftArrowFunctionKey:
        let keyDown = SKAction.moveByX(-50.0, y:0.0, duration:0.2)
        paddle.runAction(keyDown)
        print ("LEFT")
        break;
        case NSRightArrowFunctionKey:
        let keyDown = SKAction.moveByX(50.0, y:0.0, duration:0.2)
        paddle.runAction(keyDown)
        print ("RIGHT")
        break;
        default:
        break;
        }
        }
    }
    
    class GameScene: SKScene { var hoverNode: SKSpriteNode?
    //Setup
        override func mouseMoved(theEvent: NSEvent){
        let location = theEvent.locationInNode(self)
        if let hoverNode = findHoverable(self.nodeAtPoint(location)) {
        if (hoverNode == hoverNode) { return }
            scene.removeAllActions()
            node.runAction(SKAction.scaleTo(1.2, duration: 0.5))
            hoverNode = node
            } else {
            if let hoverNode = hoverNode {
            hoverNode.removeAllActions()
            hoverNode.runAction(SKAction.scaleTo(1.0, duration: 0.5))
            self.hoverNode = nil }
            private func findHoverable(hoverNode: SKNode) -> SKSpriteNode? {
            if let node = node as? SKSpriteNode {
            return node }
            if let parent = node.parent {
            if let parent = parent as? SKSpriteNode {
            return parent
            } else {
            return findHoverable(parent)
            }
            } else {
            return nil
            }
        }
    }

    
    
    
     /* [_player runAction:[SKAction moveByX:0.0f y:50.0f duration:0.3]];

    
    
    
    
    
    // KeyDown
    internal override func keyDown(theEvent: NSEvent) {
        handleKeyEvent(theEvent, keyDown: true)
    }
    internal override func keyUp(theEvent: NSEvent) {
        handleKeyEvent(theEvent, keyDown: false)
    }
    internal func handleKeyEvent(event:NSEvent, keyDown:Bool){
        if event.modifierFlags.contains(NSEventModifierFlags.NumericPadKeyMask){
            if let theArrow = event.charactersIgnoringModifiers, keyChar = theArrow.unicodeScalars.first?.value{
                switch Int(keyChar){
                case NSRightArrowFunctionKey:
                    let paddle = childNodeWithName(PaddleCategoryName) as! SKSpriteNode
                    let keyDown = SKAction.moveToX(self.frame.size.width, duration:2)
                    paddle.runAction(keyDown)
                    break
                case NSLeftArrowFunctionKey:
                    let paddle = childNodeWithName(PaddleCategoryName) as! SKSpriteNode
                    let keyDown = SKAction.moveToX(0, duration:2)
                    paddle.runAction(keyDown)
                    break
                default:
                    break
                }
            }
        }
    
    
    
    
    
   override func moveLeft(sender: AnyObject?) {
            let paddle = childNodeWithName(PaddleCategoryName) as! SKSpriteNode
            let moveLeft = SKAction.moveToX(0, duration:2)
            paddle.runAction(moveLeft)
            print("Left arrow.")
            }
        override func moveRight(sender: AnyObject?) {
            let paddle = childNodeWithName(PaddleCategoryName) as! SKSpriteNode
            let moveRight = SKAction.moveToX(self.frame.size.width, duration:2)
            paddle.runAction(moveRight)
            print("Right arrow.")
            }
    
            override func keyDown(theEvent: NSEvent) {
            //let paddle = childNodeWithName(PaddleCategoryName) as! SKSpriteNode
            //let paddlePosition = 100
                // KeyDown
                internal override func keyDown(theEvent: NSEvent) {
                    handleKeyEvent(theEvent, keyDown: true)
                }
                internal override func keyUp(theEvent: NSEvent) {
                    handleKeyEvent(theEvent, keyDown: false)
                }
                internal func handleKeyEvent(event:NSEvent, keyDown:Bool){
                    if event.modifierFlags.contains(NSEventModifierFlags.NumericPadKeyMask){
                        if let theArrow = event.charactersIgnoringModifiers, keyChar = theArrow.unicodeScalars.first?.value{
                            switch Int(keyChar){
                
                
                
                

    
            }*/
    
        
        /*override func keyDown(event: NSEvent) {
            interpretKeyEvents([event])
        // calls insertText(_:), moveUp(_:), etc.
        }*/
 
        /*
        internal override func moveLeft(theEvent: NSEvent) {
        // 1. Check whether user touched the paddle
        if isFingerOnMouse {
        // 2. Get touch location
        var click = mouseDown.first as! UIEvent
        var clickLocation = click.locationInNode(self)
        var previousLocation = click.previousLocationInNode(self)
        // 3. Get node for paddle
        var mouse = childNodeWithName(PaddleCategoryName) as! SKSpriteNode
        // 4. Calculate new position along x for paddle
        var mouseX = mouse.position.x + (mouseLocation.x - previousLocation.x)
        // 5. Limit x so that paddle won't leave screen to left or right
        mouseX = max(mouseX, mouse.size.width/2)
        mouseX = min(mouseX, size.width - mouse.size.width/2)
        // 6. Update paddle position
        paddle.position = CGPointMake(mouseX, mouse.position.y)
        }
        }
        
        
        override func clicksEnded(clicks: Set<UITouch>, withEvent event: UIEvent?) {
        isFingerOnMouse = false
        }
        func didBeginContact(contact: SKPhysicsContact) {
        // 1. Create local variables for two physics bodies
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        // 2. Assign the two physics bodies so that the one with the lower category is always stored in firstBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
        firstBody = contact.bodyA
        secondBody = contact.bodyB
        }
        else
        {
        firstBody = contact.bodyB
        secondBody = contact.bodyA
        }
        // 3. react to the contact between ball and bottom
        if firstBody.categoryBitMask == BallCategory && secondBody.categoryBitMask == BottomCategory {
        if let theView = view {
        let gameOverScene = GameOverScene.unarchiveFromFile("GameOverScene") as! GameOverScene
        gameOverScene.gameWon = false
        mainView.presentScene(gameOverScene)
        }
        }
 
        if firstBody.categoryBitMask == BallCategory && secondBody.categoryBitMask == BlockCategory {
        secondBody.node!.removeFromParent()
        if isGameWon() {
        if let mainView = view {
        let gameOverScene = GameOverScene.unarchiveFromFile("GameOverScene") as! GameOverScene
        gameOverScene.gameWon = true
        mainView.presentScene(gameOverScene)
        }
    }
}
}
         func isGameWon() -> Bool {
            var numberOfBricks = 0
            self.enumerateChildNodesWithName(BlockCategoryName) {
                node, stop in
                numberOfBricks = numberOfBricks + 1
            }
            return numberOfBricks == 0
        }
        
        func update(currentTime: NSTimeInterval) {
            let ball = self.childNodeWithName(BallCategoryName) as! SKSpriteNode
            
            let maxSpeed: CGFloat = 1000.0
            let speed = sqrt(ball.physicsBody!.velocity.dx * ball.physicsBody!.velocity.dx + ball.physicsBody!.velocity.dy * ball.physicsBody!.velocity.dy)
            
            if speed > maxSpeed {
                ball.physicsBody!.linearDamping = 0.4
            }
            else {
                ball.physicsBody!.linearDamping = 0.0
            }
        }
    }
}*/